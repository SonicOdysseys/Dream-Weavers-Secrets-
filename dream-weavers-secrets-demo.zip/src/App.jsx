
import React, { useMemo, useState, useEffect } from 'react'
import logo from './assets/logo.svg'

const BRAND = {
  name: "Dream Weavers Secrets",
  blurb: "Nature‑based, esoteric, handcrafted goods.",
  from: "from-emerald-600",
  to: "to-amber-500"
}

const DEMO_PRODUCTS = [
  { id: rid(), title: "Sunrise Spiral Earrings", price: 48, category: "jewelry", seller: "Nova", image: "https://images.unsplash.com/photo-1617038260897-5bd46fd3a9ec?w=1200&q=80&auto=format&fit=crop", description: "Hand‑hammered brass spirals kissed with dawn patina.", featured: true },
  { id: rid(), title: "Seafoam Pendant", price: 72, category: "jewelry", seller: "Ari", image: "https://images.unsplash.com/photo-1599643477877-530eb83abc8e?w=1200&q=80&auto=format&fit=crop", description: "Recycled silver with beach‑glass centerpiece." },
  { id: rid(), title: "Forest Whisper — Canvas Print", price: 180, category: "art", seller: "Elemental Echo", image: "https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=1200&q=80&auto=format&fit=crop", description: "A quiet path where light braids with mist.", featured: true },
  { id: rid(), title: "Copper Flow Bracelet", price: 39, category: "jewelry", seller: "Maya", image: "https://images.unsplash.com/photo-1603565834043-9105c73c47eb?w=1200&q=80&auto=format&fit=crop", description: "Organic wrap with adjustable clasp." },
  { id: rid(), title: "Night Sky Print", price: 95, category: "art", seller: "Orion", image: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=1200&q=80&auto=format&fit=crop", description: "Stars like seeds scattered by wind." },
]

const LS = {
  PRODUCTS: 'dws_products_v1',
  CART: 'dws_cart_v1',
}

function load(key, fallback){ try { const v = localStorage.getItem(key); return v? JSON.parse(v) : fallback } catch { return fallback } }
function save(key, value){ try { localStorage.setItem(key, JSON.stringify(value)) } catch {} }
function rid(){ return (crypto?.randomUUID?.() ?? Math.random().toString(36).slice(2)) }
const money = n => new Intl.NumberFormat(undefined, { style:'currency', currency:'USD' }).format(n)

export default function App(){
  const [products, setProducts] = useState(() => load(LS.PRODUCTS, DEMO_PRODUCTS))
  const [cart, setCart] = useState(() => load(LS.CART, []))
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('all')
  const [sort, setSort] = useState('featured')
  const [sellOpen, setSellOpen] = useState(false)
  const [compact, setCompact] = useState(false)

  useEffect(()=> save(LS.PRODUCTS, products), [products])
  useEffect(()=> save(LS.CART, cart), [cart])

  const list = useMemo(()=>{
    let items = products.filter(p => category==='all' ? true : p.category===category)
    if(query.trim()){
      const q = query.toLowerCase()
      items = items.filter(p => [p.title,p.description,p.seller].some(v => v?.toLowerCase().includes(q)))
    }
    switch (sort){
      case 'priceAsc': items.sort((a,b)=>a.price-b.price); break;
      case 'priceDesc': items.sort((a,b)=>b.price-a.price); break;
      case 'az': items.sort((a,b)=>a.title.localeCompare(b.title)); break;
      default: items.sort((a,b)=>(b.featured===true)-(a.featured===true));
    }
    return items
  }, [products, category, query, sort])

  const cartCount = cart.reduce((t,i)=>t+i.qty,0)
  const subtotal = cart.reduce((t,i)=>t+i.qty*i.price,0)

  function addToCart(p){
    setCart(c=>{
      const i = c.findIndex(x=>x.id===p.id)
      if(i>=0){ const n=[...c]; n[i] = {...n[i], qty:n[i].qty+1}; return n }
      return [...c, { id:p.id, title:p.title, price:p.price, image:p.image, seller:p.seller, qty:1 }]
    })
    window.scrollTo({ top: 0, behavior:'smooth' })
  }

  function deleteProduct(id){ setProducts(p=>p.filter(x=>x.id!==id)) }

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-slate-50 flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur bg-white/80 border-b">
        <div className="mx-auto max-w-7xl px-4 py-3 flex items-center gap-3">
          <div className="flex items-center gap-3">
            <div className={`h-10 w-10 rounded-2xl bg-gradient-to-br ${BRAND.from} ${BRAND.to} grid place-items-center overflow-hidden`}>
              <img src={logo} alt="logo" className="h-7 w-7" />
            </div>
            <div>
              <div className="font-extrabold tracking-tight text-lg sm:text-xl">{BRAND.name}</div>
              <div className="text-xs text-slate-500 hidden sm:block">{BRAND.blurb}</div>
            </div>
          </div>
          <div className="flex-1" />
          <div className="hidden md:flex items-center gap-2 w-[420px]">
            <div className="relative w-full">
              <input className="w-full pl-9 pr-3 py-2 rounded-xl border focus:ring-2 focus:ring-emerald-500 outline-none" placeholder="Search art, jewelry, sellers…" value={query} onChange={e=>setQuery(e.target.value)} />
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">🔎</div>
            </div>
            <select className="border rounded-xl px-3 py-2" value={sort} onChange={e=>setSort(e.target.value)}>
              <option value="featured">Featured</option>
              <option value="priceAsc">Price (low → high)</option>
              <option value="priceDesc">Price (high → low)</option>
              <option value="az">A → Z</option>
            </select>
          </div>
          <button className="ml-2 rounded-xl border px-3 py-2 text-sm">
            Cart <span className="ml-1 rounded-full bg-slate-900 text-white text-xs px-2 py-0.5">{cartCount}</span>
          </button>
        </div>
        {/* mobile search */}
        <div className="md:hidden px-4 pb-3 flex gap-2">
          <input className="w-full pl-3 pr-3 py-2 rounded-xl border focus:ring-2 focus:ring-emerald-500 outline-none" placeholder="Search…" value={query} onChange={e=>setQuery(e.target.value)} />
          <select className="border rounded-xl px-3 py-2" value={sort} onChange={e=>setSort(e.target.value)}>
            <option value="featured">Sort</option>
            <option value="priceAsc">Price ↑</option>
            <option value="priceDesc">Price ↓</option>
            <option value="az">A→Z</option>
          </select>
        </div>
      </header>

      {/* Hero */}
      <div className="bg-gradient-to-r from-emerald-50 to-amber-50 border-b">
        <div className="mx-auto max-w-7xl px-4 py-8 grid gap-6 md:grid-cols-[1.2fr_.8fr] items-center">
          <div>
            <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">Sell handcrafted pieces with ease</h1>
            <p className="text-slate-600 mt-2">Invite collaborators, upload photos, and showcase your work. Buyers enjoy a clean, mobile‑first browsing experience.</p>
            <div className="mt-4 flex gap-2">
              <button onClick={()=>setSellOpen(true)} className="px-4 py-2 rounded-xl bg-emerald-600 text-white">＋ List an item</button>
              <button onClick={()=>setCompact(v=>!v)} className="px-4 py-2 rounded-xl border">Toggle compact</button>
            </div>
          </div>
          <div className="rounded-3xl overflow-hidden shadow-sm">
            <img alt="Hero" src="https://images.unsplash.com/photo-1520975922284-6c0a5e9b9d6c?w=1400&q=80&auto=format&fit=crop" className="w-full h-full object-cover" />
          </div>
        </div>
      </div>

      {/* Category tabs */}
      <div className="mx-auto max-w-7xl px-4">
        <div className="flex items-center justify-between py-4 flex-wrap gap-3">
          <div className="inline-flex rounded-xl border p-1 bg-white">
            {['all','jewelry','art'].map(c=>(
              <button key={c} onClick={()=>setCategory(c)} className={`px-3 py-1.5 rounded-lg text-sm ${category===c?'bg-emerald-600 text-white':'text-slate-700'}`}>{c[0].toUpperCase()+c.slice(1)}</button>
            ))}
          </div>
          <label className="text-sm text-slate-600 flex items-center gap-2">
            <input type="checkbox" checked={compact} onChange={e=>setCompact(e.target.checked)} /> Compact view
          </label>
        </div>
        <hr />
        {/* Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 py-6">
          {list.map(p => (
            <div key={p.id} className={`overflow-hidden rounded-2xl border bg-white ${compact ? '' : 'shadow-sm hover:shadow-md transition-shadow'}`}>
              <div className="aspect-[4/3] bg-slate-100 overflow-hidden">
                <img src={p.image} alt={p.title} className="h-full w-full object-cover" loading="lazy" />
              </div>
              <div className="p-4">
                <div className="flex items-center justify-between">
                  <div className="font-semibold">{money(p.price)}</div>
                  <span className="px-2 py-1 rounded bg-slate-100 text-slate-700 text-xs capitalize">{p.category}</span>
                </div>
                <div className="mt-1 font-medium line-clamp-1">{p.title}</div>
                <div className="text-xs text-slate-500">by {p.seller}</div>
                {!compact && <p className="text-sm text-slate-600 mt-2 line-clamp-2">{p.description}</p>}
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <button onClick={()=>addToCart(p)} className="px-3 py-2 rounded-xl bg-emerald-600 text-white">Add to cart</button>
                  <button onClick={()=>deleteProduct(p.id)} className="px-3 py-2 rounded-xl border">Remove</button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {list.length===0 && (
          <div className="py-24 text-center text-slate-500">No items yet. Try a different filter or add your first product.</div>
        )}
      </div>

      {/* Sell dialog (simple) */}
      {sellOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 grid place-items-center px-4" onClick={()=>setSellOpen(false)}>
          <div className="bg-white rounded-2xl w-full max-w-lg p-4" onClick={e=>e.stopPropagation()}>
            <div className="text-lg font-bold">List a new item</div>
            <SellForm onCreate={(item)=>{ setProducts(p=>[{ id: rid(), featured:false, ...item }, ...p]); setSellOpen(false) }} />
          </div>
        </div>
      )}

      <footer className="border-t mt-auto">
        <div className="mx-auto max-w-7xl px-4 py-8 grid gap-6 md:grid-cols-3">
          <div>
            <div className="font-bold text-lg">About</div>
            <p className="text-sm text-slate-600 mt-2">A calm, simple marketplace for jewelry & art. Demo mode stores data in your browser only.</p>
          </div>
          <div>
            <div className="font-bold text-lg">How to accept payments</div>
            <p className="text-sm text-slate-600 mt-2">When you want to go live, add Stripe Payment Links to items, or connect Stripe Checkout with a tiny server.</p>
          </div>
          <div>
            <div className="font-bold text-lg">Data</div>
            <p className="text-sm text-slate-600 mt-2">No account needed. Add, search, sort, and cart work offline after first load.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

function SellForm({ onCreate }){
  const [title, setTitle] = useState('')
  const [price, setPrice] = useState('')
  const [category, setCategory] = useState('jewelry')
  const [seller, setSeller] = useState('')
  const [desc, setDesc] = useState('')
  const [image, setImage] = useState('')

  function submit(e){
    e.preventDefault()
    if(!title || !price || !seller) return
    onCreate({ title, price: Number(price), category, seller, description: desc, image: image || placeholderFor(category) })
  }

  return (
    <form onSubmit={submit} className="space-y-3 mt-3">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <label className="text-sm">Title<input className="mt-1 w-full border rounded-xl px-3 py-2" value={title} onChange={e=>setTitle(e.target.value)} placeholder="Quartz Drop Necklace" /></label>
        <label className="text-sm">Price (USD)<input type="number" min="0" step="0.01" className="mt-1 w-full border rounded-xl px-3 py-2" value={price} onChange={e=>setPrice(e.target.value)} placeholder="49" /></label>
        <div className="text-sm">
          Category
          <div className="flex gap-2 mt-2">
            {['jewelry','art'].map(c=>(
              <button type="button" key={c} onClick={()=>setCategory(c)} className={`px-3 py-2 rounded-xl border ${category===c?'bg-emerald-600 text-white':''}`}>{c[0].toUpperCase()+c.slice(1)}</button>
            ))}
          </div>
        </div>
        <label className="text-sm">Seller name<input className="mt-1 w-full border rounded-xl px-3 py-2" value={seller} onChange={e=>setSeller(e.target.value)} placeholder="Your shop name" /></label>
        <label className="sm:col-span-2 text-sm">Description<textarea rows="3" className="mt-1 w-full border rounded-xl px-3 py-2" value={desc} onChange={e=>setDesc(e.target.value)} placeholder="Short description"></textarea></label>
        <label className="sm:col-span-2 text-sm">Image URL<input className="mt-1 w-full border rounded-xl px-3 py-2" value={image} onChange={e=>setImage(e.target.value)} placeholder="Paste an image URL" /></label>
      </div>
      <div className="flex justify-end gap-2 pt-2">
        <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-600 text-white">Add item</button>
      </div>
    </form>
  )
}

function placeholderFor(category){
  if(category==='art') return "https://images.unsplash.com/photo-1504198266285-165a3f2a0943?w=1200&q=80&auto=format&fit=crop"
  return "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=1200&q=80&auto=format&fit=crop"
}
